const API_URL = 'https://pokeapi.co/api/v2/pokemon';

const fetchButton = document.getElementById('fetchButton');
const searchForm = document.getElementById('searchForm');
const searchInput = document.getElementById('searchInput');
const showAllButton = document.getElementById('showAllButton');
const pokemonGrid = document.getElementById('pokemonGrid');
const message = document.getElementById('message');
const resultsTitle = document.getElementById('resultsTitle');
const resultCount = document.getElementById('resultCount');

fetchButton.addEventListener('click', fetchPokemon);
searchForm.addEventListener('submit', searchPokemon);
showAllButton.addEventListener('click', () => {
  searchInput.value = '';
  fetchPokemon();
});

async function fetchPokemon() {
  setLoading(true);
  pokemonGrid.replaceChildren();
  resultsTitle.textContent = 'Pokémon collection';
  showMessage('Loading Pokémon from PokéAPI...');

  try {
    // First request gets a list of 20 Pokémon and their detail URLs.
    const response = await fetch(`${API_URL}?limit=20&offset=0`);
    if (!response.ok) {
      throw new Error(`The API returned an error (${response.status}).`);
    }

    const data = await response.json();

    // Fetch the details for all 20 Pokémon.
    const pokemonDetails = await Promise.all(
      data.results.map(async (pokemon) => {
        const detailResponse = await fetch(pokemon.url);
        if (!detailResponse.ok) {
          throw new Error(`Could not load ${pokemon.name}.`);
        }
        return await detailResponse.json();
      })
    );

    displayPokemon(pokemonDetails);
    showMessage('');
    resultsTitle.textContent = 'Pokémon collection';
    resultCount.textContent = `${pokemonDetails.length} Pokémon displayed`;
  } catch (error) {
    showMessage(`Unable to load Pokémon. ${error.message} Please check your internet connection and try again.`, true);
    resultCount.textContent = 'No results';
  } finally {
    setLoading(false);
  }
}

async function searchPokemon(event) {
  event.preventDefault();
  const searchTerm = searchInput.value.trim().toLowerCase();

  if (!searchTerm) {
    showMessage('Enter a Pokémon name or Pokédex number to search.', true);
    searchInput.focus();
    return;
  }

  setLoading(true);
  pokemonGrid.replaceChildren();
  resultsTitle.textContent = 'Search result';
  showMessage(`Searching for ${searchTerm}...`);

  try {
    // PokéAPI accepts a Pokémon name or its Pokédex number in the URL.
    const response = await fetch(`${API_URL}/${encodeURIComponent(searchTerm)}`);

    if (response.status === 404) {
      throw new Error(`No Pokémon named or numbered "${searchTerm}" was found.`);
    }
    if (!response.ok) {
      throw new Error(`The API returned an error (${response.status}).`);
    }

    const pokemon = await response.json();
    displayPokemon([pokemon]);
    showMessage('');
    resultCount.textContent = '1 Pokémon found';
  } catch (error) {
    showMessage(error.message || 'Something went wrong while searching. Please try again.', true);
    resultCount.textContent = 'No results';
  } finally {
    setLoading(false);
  }
}

function displayPokemon(pokemonList) {
  pokemonGrid.replaceChildren();

  pokemonList.forEach((pokemon) => {
    const card = document.createElement('article');
    card.className = 'pokemon-card';

    const top = document.createElement('div');
    top.className = 'card-top';

    const number = document.createElement('span');
    number.className = 'pokemon-number';
    number.textContent = `#${String(pokemon.id).padStart(3, '0')}`;

    const name = document.createElement('h3');
    name.className = 'pokemon-name';
    name.textContent = pokemon.name;

    top.append(number);
    top.append(name);

    const imageWrap = document.createElement('div');
    imageWrap.className = 'pokemon-image-wrap';

    const image = document.createElement('img');
    image.className = 'pokemon-image';
    image.src = pokemon.sprites.other['official-artwork'].front_default
      || pokemon.sprites.front_default
      || '';
    image.alt = `${pokemon.name} image`;
    image.loading = 'lazy';
    imageWrap.append(image);

    const typeList = document.createElement('div');
    typeList.className = 'type-list';

    pokemon.types.forEach((typeInfo) => {
      const type = document.createElement('span');
      type.className = `type type-${typeInfo.type.name}`;
      type.textContent = typeInfo.type.name;
      typeList.append(type);
    });

    const details = document.createElement('div');
    details.className = 'card-details';

    const height = createDetail('Height', `${pokemon.height / 10} m`);
    const weight = createDetail('Weight', `${pokemon.weight / 10} kg`);
    details.append(height, weight);

    card.append(top, imageWrap, typeList, details);
    pokemonGrid.append(card);
  });
}

function createDetail(label, value) {
  const wrapper = document.createElement('div');
  wrapper.className = 'detail';

  const strong = document.createElement('strong');
  strong.textContent = value;

  const small = document.createElement('span');
  small.textContent = label;

  wrapper.append(strong, small);
  return wrapper;
}

function showMessage(text, isError = false) {
  message.textContent = text;
  message.className = isError ? 'message error' : 'message';
}

function setLoading(isLoading) {
  fetchButton.disabled = isLoading;
  fetchButton.textContent = isLoading ? 'Loading...' : 'Load 20 Pokémon';
}
